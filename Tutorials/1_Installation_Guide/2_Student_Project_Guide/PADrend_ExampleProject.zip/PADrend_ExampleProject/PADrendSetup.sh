find /usr/local/ /opt/ $HOME -name main.escript -path */plugins/main.escript -exec sh -c "dirname {} | xargs ln -s " \; -quit
find /usr/local/ /opt/ $HOME -name SBExperiments -path */extPlugins/SBExperiments -exec sh -c "dirname {} | xargs ln -s " \; -quit
find /usr/local/ /opt/ $HOME -name Std -path */EScript/Std -exec sh -c "dirname {} | xargs ln -s " \; -quit
find /usr/local/ /opt/ $HOME -name PADrend -executable -type f -exec ln -s {} \; -quit

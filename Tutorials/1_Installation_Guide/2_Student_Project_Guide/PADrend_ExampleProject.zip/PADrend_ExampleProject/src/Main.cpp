
#include "ExampleRenderer/E_ExampleRenderer.h"
#include <EScript/EScript.h>

#include <iostream>

#ifndef LIBRARY_NAME
#define LIBRARY_NAME "Unknown" // Will be set by CMake
#endif

extern "C" void initLibrary(EScript::Namespace* lib) {
  std::cout << "Loading Library: " << LIBRARY_NAME << "..." << std::endl;
  if(lib->getAttribute(LIBRARY_NAME).isNotNull()) {
    std::cerr << LIBRARY_NAME << " Library already loaded!" << std::endl;
  } else {
    auto * ns = new EScript::Namespace;
	  declareConstant(lib, LIBRARY_NAME, ns);
    
    // Initialize EScript Objects
    ExampleProject::E_ExampleRenderer::init(*ns);
  } 
}


#include "E_ExampleRenderer.h"

#include <EScript/EScript.h>

namespace E_DynLibExample {

EScript::Type * E_ExampleRenderer::typeObject = nullptr;

//! initMembers
void E_ExampleRenderer::init(EScript::Namespace & lib) {
	/// [E_ExampleRenderer] ---|> [E_State] ---|> [E_GroupNode] ---|> [E_Node]
	typeObject = new EScript::Type(E_State::getTypeObject());
	declareConstant(&lib,getClassName(),typeObject);
	addFactory<DynLibExample::ExampleRenderer,E_ExampleRenderer>();

	//! [ESMF] new DynLibExample.ExampleRenderer
	ES_CTOR(typeObject,0,0,EScript::create(new DynLibExample::ExampleRenderer))
}

// ------------------------------------------------------------

//! [ctor]
E_ExampleRenderer::E_ExampleRenderer(DynLibExample::ExampleRenderer * gNode,
												EScript::Type * type) :
	E_State(gNode, type ? type : typeObject) {
}

//! [dtor]
E_ExampleRenderer::~E_ExampleRenderer() {
}

}

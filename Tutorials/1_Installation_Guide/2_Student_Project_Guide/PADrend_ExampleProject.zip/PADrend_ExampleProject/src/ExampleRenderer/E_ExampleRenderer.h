
#ifndef __E_ExampleRenderer_H
#define __E_ExampleRenderer_H

#include <E_MinSG/Core/States/E_State.h>

#include "ExampleRenderer.h"

namespace E_DynLibExample {

/**
 *   [E_ExampleRenderer] ---|> [E_State]
 */
class E_ExampleRenderer : public E_MinSG::E_State {
		ES_PROVIDES_TYPE_NAME(ExampleRenderer)
	public:
		template<class, class, class> friend class Util::PolymorphicWrapperCreator;

		// ---
		static EScript::Type * typeObject;
		static void init(EScript::Namespace & lib);

		virtual ~E_ExampleRenderer();

		const DynLibExample::ExampleRenderer * operator*()const		{	return static_cast<const DynLibExample::ExampleRenderer*>(ref().get());	}
		DynLibExample::ExampleRenderer * operator*()				{	return static_cast<DynLibExample::ExampleRenderer*>(ref().get());	}


	protected:
		E_ExampleRenderer(DynLibExample::ExampleRenderer * gNode, EScript::Type * type = nullptr);
};
}

ES_CONV_EOBJ_TO_OBJ(E_DynLibExample::E_ExampleRenderer, DynLibExample::ExampleRenderer *, **eObj)

#endif // __E_ExampleRenderer_H

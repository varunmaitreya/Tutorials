LD_LIBRARY_PATH=/usr/local/lib:./lib:./lib64:./lib/opencollada:/usr/local/lib64:/usr/local/lib/opencollada PADrend --script=/usr/local/share/PADrend/plugins/main.escript
